package com.spring.back_springboot.pojo;

import lombok.Data;

@Data
public class files
{
    private int id;
    private String file;
    private String name;
    private String type;
    private String markdownText;
}
