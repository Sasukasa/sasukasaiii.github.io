package com.spring.back_springboot.pojo;

import lombok.Data;

@Data
public class languageText
{
    private int id;
    private String language;
    private String text;
}
