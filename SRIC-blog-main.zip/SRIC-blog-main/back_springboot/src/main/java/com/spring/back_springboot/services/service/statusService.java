package com.spring.back_springboot.services.service;

import com.spring.back_springboot.pojo.status;

import java.util.List;

public interface statusService
{
    List<status> getAllStatus();
}
