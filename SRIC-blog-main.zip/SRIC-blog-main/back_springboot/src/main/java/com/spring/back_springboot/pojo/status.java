package com.spring.back_springboot.pojo;

import lombok.Data;

@Data
public class status
{
    private int id;
    private String status;
}
