package com.spring.back_springboot.services.service;

import com.spring.back_springboot.pojo.dictionary;

import java.util.List;

public interface dictionaryService
{
    List<dictionary> getDictElColorType();
}
