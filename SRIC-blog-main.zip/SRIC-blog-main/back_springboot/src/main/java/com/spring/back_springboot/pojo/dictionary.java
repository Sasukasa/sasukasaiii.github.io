package com.spring.back_springboot.pojo;

import lombok.Data;

@Data
public class dictionary
{
    private int id;
    private String label;
    private String value;
}
