package com.spring.back_springboot.pojo;

import lombok.Data;

@Data
public class tag
{
    private int id;
    private int uid;
    private String content;
}
