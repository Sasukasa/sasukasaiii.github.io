package com.spring.back_springboot.pojo;

import lombok.Data;

@Data
public class pageVisited
{
    private int id;
    private String page;
    private int visited;
}
