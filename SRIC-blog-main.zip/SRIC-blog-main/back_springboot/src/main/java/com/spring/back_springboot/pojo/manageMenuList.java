package com.spring.back_springboot.pojo;

import lombok.Data;

@Data
public class manageMenuList
{
    private int id;
    private String name;
    private String navItem;
    private String icon;
    private String zh;
    private String en;
    private String warma;
}
