package com.spring.back_springboot.pojo;

import lombok.Data;

@Data
public class resourcesCategory
{
    private int id;
    private String content;
    private String icon;
}
