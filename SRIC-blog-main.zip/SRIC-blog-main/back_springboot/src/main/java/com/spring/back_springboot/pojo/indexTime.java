package com.spring.back_springboot.pojo;
import lombok.Data;

@Data
public class indexTime
{
    private int id;
    private String content;
    private String timestamp;
    private String type;
    private String color;
}
