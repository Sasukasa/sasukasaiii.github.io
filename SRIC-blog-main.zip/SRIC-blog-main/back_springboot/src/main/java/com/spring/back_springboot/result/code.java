package com.spring.back_springboot.result;
import lombok.Data;

@Data
public class code
{
    private int code;
    public code(int c){code = c;}
}
