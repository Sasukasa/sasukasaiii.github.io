export default
{
    name: 'LinkCardGitHub',
    data()
    {
        return{
            MarkGitHub: require('@/assets/webp/logo/mark-32ea3e.webp')
        }
    }
}