export default
{
    name: 'LinkCardBilibili',
    data()
    {
        return{
            MarkBilibili: require('@/assets/webp/logo/mark-fb7299.webp')
        }
    }
}