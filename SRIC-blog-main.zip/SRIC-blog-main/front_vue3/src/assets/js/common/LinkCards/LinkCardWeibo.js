export default
{
    name: 'LinkCardWeibo',
    data()
    {
        return{
            MarkWeibo: require('@/assets/webp/logo/mark-fdf66d.webp')
        }
    }
}